import Vue from 'vue'
import VueMultiselect from 'vue-multiselect'
Vue.use(VueMultiselect)