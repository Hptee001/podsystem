import Vue from 'vue'
import VueDraggable from 'vuedraggable'
Vue.use(VueDraggable)