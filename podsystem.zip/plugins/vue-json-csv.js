import Vue from 'vue'
import JsonCSV from 'vue-json-csv'
Vue.use(JsonCSV)