import Vue from 'vue'
import FileSaver from 'file-saver'
Vue.use(FileSaver)