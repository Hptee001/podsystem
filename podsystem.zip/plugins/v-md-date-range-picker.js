import Vue from 'vue';
import VMdDateRangePicker from "v-md-date-range-picker";
Vue.use(VMdDateRangePicker);