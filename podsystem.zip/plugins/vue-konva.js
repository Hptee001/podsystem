import Vue from 'vue';
import VueKonva from 'vue-konva';

Vue.use(VueKonva);