import Vue from 'vue'
import CoreUI from '@coreui/vue'
Vue.use(CoreUI)