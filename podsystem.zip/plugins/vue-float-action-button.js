import Vue from 'vue'
import VueFab from 'vue-float-action-button'
Vue.use(VueFab)