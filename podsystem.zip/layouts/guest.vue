<template>
  <div id="appRoot">
    <nuxt />
  </div>
</template>

<script>
  export default {}
</script>
