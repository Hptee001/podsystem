<template>
    <div class="line"></div>
</template>
<style >
.line{
width: 100%;
height: 10px;
border-bottom: 1px solid black;
}
</style>