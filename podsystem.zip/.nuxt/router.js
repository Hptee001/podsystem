import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7d16f82f = () => interopDefault(import('..\\pages\\handle\\cards\\index.vue' /* webpackChunkName: "pages/handle/cards/index" */))
const _38e3c0bd = () => interopDefault(import('..\\pages\\handle\\collections\\index.vue' /* webpackChunkName: "pages/handle/collections/index" */))
const _36881d50 = () => interopDefault(import('..\\pages\\handle\\order-esty\\index.vue' /* webpackChunkName: "pages/handle/order-esty/index" */))
const _c6a612ce = () => interopDefault(import('..\\pages\\handle\\templates\\index.vue' /* webpackChunkName: "pages/handle/templates/index" */))
const _1b8fc957 = () => interopDefault(import('..\\pages\\notifications\\Alerts.vue' /* webpackChunkName: "pages/notifications/Alerts" */))
const _2cebe920 = () => interopDefault(import('..\\pages\\notifications\\Badges.vue' /* webpackChunkName: "pages/notifications/Badges" */))
const _52fc82a6 = () => interopDefault(import('..\\pages\\notifications\\Modals.vue' /* webpackChunkName: "pages/notifications/Modals" */))
const _193bfc7d = () => interopDefault(import('..\\pages\\pages\\Login.vue' /* webpackChunkName: "pages/pages/Login" */))
const _15b6f65d = () => interopDefault(import('..\\pages\\pages\\Page404.vue' /* webpackChunkName: "pages/pages/Page404" */))
const _4a64d39a = () => interopDefault(import('..\\pages\\pages\\Page500.vue' /* webpackChunkName: "pages/pages/Page500" */))
const _49fc6f3f = () => interopDefault(import('..\\pages\\pages\\Register.vue' /* webpackChunkName: "pages/pages/Register" */))
const _5e9919c1 = () => interopDefault(import('..\\pages\\reports\\report-cards.vue' /* webpackChunkName: "pages/reports/report-cards" */))
const _553a0972 = () => interopDefault(import('..\\pages\\reports\\report-dashboard.vue' /* webpackChunkName: "pages/reports/report-dashboard" */))
const _49135a77 = () => interopDefault(import('..\\pages\\reports\\report-orders.vue' /* webpackChunkName: "pages/reports/report-orders" */))
const _23902f0f = () => interopDefault(import('..\\pages\\reports\\report-sale-designer.vue' /* webpackChunkName: "pages/reports/report-sale-designer" */))
const _45af2274 = () => interopDefault(import('..\\pages\\resources\\account-store.vue' /* webpackChunkName: "pages/resources/account-store" */))
const _05c160fa = () => interopDefault(import('..\\pages\\resources\\accounts.vue' /* webpackChunkName: "pages/resources/accounts" */))
const _4dc59890 = () => interopDefault(import('..\\pages\\handle\\order-esty\\_id.vue' /* webpackChunkName: "pages/handle/order-esty/_id" */))
const _39dc0cec = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/handle/cards",
    component: _7d16f82f,
    name: "handle-cards"
  }, {
    path: "/handle/collections",
    component: _38e3c0bd,
    name: "handle-collections"
  }, {
    path: "/handle/order-esty",
    component: _36881d50,
    name: "handle-order-esty"
  }, {
    path: "/handle/templates",
    component: _c6a612ce,
    name: "handle-templates"
  }, {
    path: "/notifications/Alerts",
    component: _1b8fc957,
    name: "notifications-Alerts"
  }, {
    path: "/notifications/Badges",
    component: _2cebe920,
    name: "notifications-Badges"
  }, {
    path: "/notifications/Modals",
    component: _52fc82a6,
    name: "notifications-Modals"
  }, {
    path: "/pages/Login",
    component: _193bfc7d,
    name: "pages-Login"
  }, {
    path: "/pages/Page404",
    component: _15b6f65d,
    name: "pages-Page404"
  }, {
    path: "/pages/Page500",
    component: _4a64d39a,
    name: "pages-Page500"
  }, {
    path: "/pages/Register",
    component: _49fc6f3f,
    name: "pages-Register"
  }, {
    path: "/reports/report-cards",
    component: _5e9919c1,
    name: "reports-report-cards"
  }, {
    path: "/reports/report-dashboard",
    component: _553a0972,
    name: "reports-report-dashboard"
  }, {
    path: "/reports/report-orders",
    component: _49135a77,
    name: "reports-report-orders"
  }, {
    path: "/reports/report-sale-designer",
    component: _23902f0f,
    name: "reports-report-sale-designer"
  }, {
    path: "/resources/account-store",
    component: _45af2274,
    name: "resources-account-store"
  }, {
    path: "/resources/accounts",
    component: _05c160fa,
    name: "resources-accounts"
  }, {
    path: "/handle/order-esty/:id?",
    component: _4dc59890,
    name: "handle-order-esty-id"
  }, {
    path: "/",
    component: _39dc0cec,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
